int obsessive_compulsive_host_check_processor(host *hst) {}
int handle_host_event(host *hst) {}
