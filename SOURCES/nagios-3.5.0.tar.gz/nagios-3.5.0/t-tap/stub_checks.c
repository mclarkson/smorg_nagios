void schedule_host_check(host *hst, time_t check_time, int options) {}
void schedule_service_check(service *svc, time_t check_time, int options) {}
