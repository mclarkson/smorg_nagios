int read_initial_state_information(void) {}
int save_state_information(int autosave) {}
